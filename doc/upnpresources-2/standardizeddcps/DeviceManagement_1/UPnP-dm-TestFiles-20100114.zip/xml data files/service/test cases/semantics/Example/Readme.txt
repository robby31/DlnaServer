The file name "pwrdim1.SemanticTests.xml" describes a simple light device which can be for instance switched on and dimmed using UPnP Device Management.

--

Xavier Roubaud